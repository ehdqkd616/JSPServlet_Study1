package lab.web.el;

public class CeilEl {

	public static double pageCeil(double num) {
		return Math.ceil(num);
	}
	
}
